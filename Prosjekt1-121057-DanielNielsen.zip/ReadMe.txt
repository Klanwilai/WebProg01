Hei!

Endelig oppgave indexClass.html og classScripts.js

I zip - Oppgave1-4 så finner du første utkastet av oppgaven min, altså oppgaven før jeg puttet alt i en klasse.
Denne versjonen av oppgaven gjør litt mer, men løser ikke oppgave 5, følte bare for å ta den med i innleveringen.
